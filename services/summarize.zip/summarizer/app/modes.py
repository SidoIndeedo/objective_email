Modes = {
    "chill": "Summarize the following in a casual and relaxed tone:",
    "professional": "Summarize this email in a formal, concise tone:",
    "important-only": "Extract only the key information, ignore filler or fluff:"
}
